import os
import cv2
import numpy as np
import random
import time
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import math
from sklearn.cluster import KMeans

# --- Flask App Initialization ---
app = Flask(__name__)
CORS(app)

# --- Folder Setup ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static/uploads/')
GENERATED_FOLDER = os.path.join(BASE_DIR, 'static/generated/')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(GENERATED_FOLDER, exist_ok=True)


# ---------------------------------------------------------------------
# SECTION 1: MANDALA GENERATION ENGINE
# ---------------------------------------------------------------------
class AdvancedMandalaGenerator:
    # This class is unchanged and remains here for the Generator tab
    def __init__(self, width, height):
        self.width, self.height, self.center = width, height, (width//2, height//2)
        self.canvas = np.ones((height, width, 3), dtype="uint8") * 255
        self.color = (random.randint(0,50), random.randint(0,50), random.randint(0,50))
        self.thickness = max(1, int(min(width, height) * 0.0025))
    def get_point(self, r, a):
        x = self.center[0] + r * math.cos(math.radians(a))
        y = self.center[1] + r * math.sin(math.radians(a))
        return (int(x), int(y))
    def draw_symmetrically(self, draw_func, n, *args):
        for i in range(n):
            slice_canvas = np.zeros_like(self.canvas)
            draw_func(slice_canvas, *args)
            M = cv2.getRotationMatrix2D(self.center, i * (360.0/n), 1.0)
            rotated = cv2.warpAffine(slice_canvas, M, (self.width, self.height))
            self.canvas = np.where(rotated > 0, rotated, self.canvas)
    def motif_scallops(self, c, r1, r2):
        p1,p2,p3=self.get_point(r1,0),self.get_point(r1,15),self.get_point(r2,7.5)
        cv2.line(c,p1,p3,self.color,self.thickness,cv2.LINE_AA); cv2.line(c,p2,p3,self.color,self.thickness,cv2.LINE_AA)
    def motif_petals(self, c, r1, r2):
        p1,p2,p3=self.get_point(r1,-5),self.get_point(r1,5),self.get_point(r2,0)
        cv2.line(c,p1,p3,self.color,self.thickness,cv2.LINE_AA); cv2.line(c,p2,p3,self.color,self.thickness,cv2.LINE_AA)
    def motif_beziers(self, c, r1, r2):
        p1,p2=self.get_point(r1,0),self.get_point(r2,10);c1,c2=self.get_point((r1+r2)/2,-5),self.get_point((r1+r2)/2,5)
        cv2.polylines(c, [np.array([[p1,c1,c2,p2]], dtype=np.int32)], False, self.color, self.thickness, cv2.LINE_AA)
    def generate(self):
        s,l=random.choice([16,24,32]),random.randint(6,10); r_max=min(self.center)*0.95; r=r_max*0.1
        step=(r_max-r)/l; cv2.circle(self.canvas,self.center,int(r/2),self.color,-1)
        for i in range(l):
            r1,r2=r,r+step*random.uniform(0.7,1.0)
            self.draw_symmetrically(random.choice([self.motif_scallops,self.motif_petals,self.motif_beziers]),s,r1,r2)
            if i%2==0: cv2.circle(self.canvas,self.center,int(r2),self.color,self.thickness,cv2.LINE_AA)
            r=r2+self.thickness
        return self.canvas

# ---------------------------------------------------------------------
# SECTION 2: KOLAM ANALYSIS ENGINE - REWRITTEN FOR NEW OUTPUT
# ---------------------------------------------------------------------

def analyze_grid_size(dots, tolerance_ratio=0.05):
    if len(dots) < 4: return "1 x 1"
    img_size = max(np.max(dots[:, 0]), np.max(dots[:, 1]))
    tolerance = img_size * tolerance_ratio
    
    def count_clusters(coords):
        coords = sorted(coords)
        if not coords: return 0
        clusters = 1
        current_cluster_start = coords[0]
        for i in range(1, len(coords)):
            if coords[i] - current_cluster_start > tolerance:
                clusters += 1
                current_cluster_start = coords[i]
        return clusters

    x_coords = dots[:, 0]
    y_coords = dots[:, 1]
    cols = count_clusters(x_coords)
    rows = count_clusters(y_coords)
    return f"{rows} x {cols}"

def analyze_complexity(binary_img):
    density = np.sum(binary_img > 0) / binary_img.size
    complexity = min(10, int(density * 50) + 1) # Scale density to a 1-10 score
    return f"{complexity}/10"

def analyze_symmetry(gray_img):
    _, binary = cv2.threshold(gray_img, 128, 255, cv2.THRESH_BINARY_INV)
    h, w = binary.shape; center = (w // 2, h // 2); scores = {}
    for k in [4, 6, 8, 12, 16, 24]:
        angle = 360.0 / k
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(binary, M, (w, h))
        intersection=np.logical_and(binary,rotated).sum(); union=np.logical_or(binary,rotated).sum()
        iou_score=intersection/union if union>0 else 0; scores[k]=iou_score
    if not scores: return "N/A", 0.0
    best_k=max(scores,key=scores.get); best_score=scores[best_k]
    return (f"{best_k}-fold radial" if best_score > 0.4 else "Asymmetric", best_score)

def analyze_colors(img, num_colors=5):
    pixels = np.float32(img.reshape((-1, 3)))
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)
    _, _, centers = cv2.kmeans(pixels, num_colors, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
    return [f"#{c[2]:02x}{c[1]:02x}{c[0]:02x}" for c in np.uint8(centers)]

# --- API ENDPOINTS ---
@app.route('/generate-kolam', methods=['POST'])
def handle_generation():
    file = request.files.get('file'); side = 600
    if file:
        img = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_COLOR)
        if img is not None: side = min(img.shape[0], img.shape[1])
    try:
        urls = []
        for i in range(3):
            gen = AdvancedMandalaGenerator(side, side)
            canvas = gen.generate()
            filename = f"mandala_v{i+1}_{int(time.time())}.png"
            cv2.imwrite(os.path.join(GENERATED_FOLDER, filename), canvas)
            urls.append(f"/generated/{filename}")
        return jsonify({'generated_urls': urls})
    except Exception as e:
        print(f"Generator Error: {e}"); return jsonify({'error': 'Generation failed.'}), 500

@app.route('/analyze-kolam', methods=['POST'])
def handle_analysis():
    file = request.files.get('file')
    if not file: return jsonify({'error': 'No file part'}), 400
    try:
        nparr = np.frombuffer(file.read(), np.uint8)
        img_color = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img_color is None: return jsonify({'error': 'Could not read image.'}), 400
        
        img_gray = cv2.cvtColor(img_color, cv2.COLOR_BGR2GRAY)
        binary_inv = cv2.adaptiveThreshold(img_gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)
        
        dots = cv2.goodFeaturesToTrack(image=img_gray, maxCorners=200, qualityLevel=0.02, minDistance=15)
        
        # Calculations for the new results format
        grid_size_str = analyze_grid_size(dots.reshape(-1, 2)) if dots is not None else "N/A"
        complexity_str = analyze_complexity(binary_inv)
        symmetry_str, symmetry_score = analyze_symmetry(img_gray)
        colors_hex = analyze_colors(img_color)

        return jsonify({
            'grid_size': grid_size_str,
            'symmetry': symmetry_str,
            'complexity': complexity_str,
            'confidence_percent': int(symmetry_score * 100),
            'dominant_colors': colors_hex,
        })
    except Exception as e:
        print(f"Analysis Error: {e}"); return jsonify({'error': 'Analysis failed.'}), 500

@app.route('/generated/<filename>')
def send_generated_file(filename):
    return send_from_directory(GENERATED_FOLDER, filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

