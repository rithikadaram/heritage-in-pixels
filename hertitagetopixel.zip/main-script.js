// =================================================================
// INITIALIZATION & CORE UI
// =================================================================

document.addEventListener('DOMContentLoaded', function() {
    // This function runs once the entire page is loaded.
    initializeTabSwitching();
    initializeGeneratorFromImage();
    initializeAnalyzer();
    initializeUIExtras();
    initializeDrawingCanvas(); // This now contains the corrected canvas logic

    showToast('Welcome to Kolam Generator! 🎨', 'info');
});

function initializeTabSwitching() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.section');

    function showSection(targetId) {
        sections.forEach(section => {
            section.classList.toggle('active', '#' + section.id === targetId);
        });
        navLinks.forEach(link => {
            link.classList.toggle('active', link.getAttribute('href') === targetId);
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href');
            showSection(targetId);
        });
    });

    // Show the default active section on page load
    const activeLink = document.querySelector('.nav-link.active');
    if (activeLink) {
        showSection(activeLink.getAttribute('href'));
    } else if (navLinks.length > 0) {
        // Fallback to show the first section if none are marked active
        showSection(navLinks[0].getAttribute('href'));
    }
}

function initializeUIExtras() {
    // This function handles the user profile dropdown menu
    const profileBtn = document.querySelector('.profile-btn');
    if (profileBtn) {
        profileBtn.addEventListener('click', () => {
            document.getElementById('profileMenu')?.classList.toggle('show');
        });
    }

    // Close dropdown if clicked outside
    document.addEventListener('click', function(e) {
        const profileMenu = document.getElementById('profileMenu');
        const isProfileButton = e.target.closest('.profile-btn');
        if (profileMenu && !profileMenu.contains(e.target) && !isProfileButton) {
            profileMenu.classList.remove('show');
        }
    });
}


// =================================================================
// SECTION 1: GENERATE KOLAM FROM IMAGE (API-Driven)
// =================================================================
// This section remains unchanged.

function initializeGeneratorFromImage() {
    const kolamForm = document.getElementById('kolam-upload-form');
    if (!kolamForm) return;

    const fileInput = document.getElementById('kolam-file-input');
    const loadingDiv = document.getElementById('kolam-loading');
    const resultsContainer = document.getElementById('results-display-area');
    const uploadArea = document.getElementById('imageUploadArea');
    const uploadContent = uploadArea.querySelector('.upload-content h4');
    const API_URL = 'http://127.0.0.1:5000';

    fileInput.addEventListener('change', () => {
        uploadContent.textContent = fileInput.files.length > 0 ? fileInput.files[0].name : 'Drag & Drop an image here';
    });

    uploadArea.addEventListener('dragover', e => {
        e.preventDefault();
        uploadArea.classList.add('active');
    });
    uploadArea.addEventListener('dragleave', () => uploadArea.classList.remove('active'));
    uploadArea.addEventListener('drop', e => {
        e.preventDefault();
        uploadArea.classList.remove('active');
        if (e.dataTransfer.files.length > 0) {
            fileInput.files = e.dataTransfer.files;
            fileInput.dispatchEvent(new Event('change'));
        }
    });

    kolamForm.addEventListener('submit', async function(event) {
        event.preventDefault();
        if (fileInput.files.length === 0) {
            showToast('Please select an image file first.', 'warning');
            return;
        }

        const formData = new FormData();
        formData.append('file', fileInput.files[0]);

        loadingDiv.style.display = 'block';
        resultsContainer.innerHTML = '';

        try {
            const response = await fetch(`${API_URL}/generate-kolam`, {
                method: 'POST',
                body: formData
            });
            if (!response.ok) throw new Error(`API request failed with status ${response.status}`);
            const data = await response.json();
            if (data.error) throw new Error(data.error);

            if (data.generated_urls && data.generated_urls.length > 0) {
                data.generated_urls.forEach(imageUrl => {
                    const img = document.createElement('img');
                    img.src = `${API_URL}${imageUrl}`;
                    img.alt = 'Generated Design';
                    img.className = 'generated-kolam-image';
                    resultsContainer.appendChild(img);
                });
            } else {
                 resultsContainer.innerHTML = `<p>No designs were generated. Please try another image.</p>`;
            }
        } catch (error) {
            console.error('Generator Error:', error);
            showToast(`Failed to generate designs: ${error.message}. Is the Python server running?`, 'error');
        } finally {
            loadingDiv.style.display = 'none';
        }
    });
}

// =================================================================
// SECTION 2: KOLAM ANALYZER (API-Driven)
// =================================================================
// This section's JS is correct but depends on a running Python server.

function initializeAnalyzer() {
    const analyzeBtn = document.getElementById('analyzeBtn');
    const fileInput = document.getElementById('imageInput');
    const uploadArea = document.getElementById('uploadArea');
    const uploadAreaText = document.getElementById('uploadAreaText'); // Assuming you have an element for text

    if (!analyzeBtn || !fileInput || !uploadArea) return;

    analyzeBtn.addEventListener('click', analyzeImage);
    uploadArea.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (event) => {
        if (fileInput.files.length > 0) {
            analyzeBtn.disabled = false;
            const reader = new FileReader();
            reader.onload = e => {
                // Display image preview
                uploadArea.style.backgroundImage = `url('${e.target.result}')`;
                uploadArea.style.backgroundSize = 'contain';
                uploadArea.style.backgroundPosition = 'center';
                uploadArea.style.backgroundRepeat = 'no-repeat';
                if(uploadAreaText) uploadAreaText.style.display = 'none'; // Hide text
            };
            reader.readAsDataURL(fileInput.files[0]);
        }
    });

    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    uploadArea.addEventListener('dragleave', () => uploadArea.classList.remove('dragover'));
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        if (e.dataTransfer.files.length > 0) {
            fileInput.files = e.dataTransfer.files;
            fileInput.dispatchEvent(new Event('change'));
        }
    });
}

async function analyzeImage() {
    const fileInput = document.getElementById('imageInput');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const resultsContent = document.getElementById('resultsContent');
    const API_URL = 'http://127.0.0.1:5000';

    if (fileInput.files.length === 0) {
        showToast('Please choose an image to analyze.', 'warning');
        return;
    }

    resultsContent.innerHTML = `<div class="no-results"><i class="fas fa-spinner fa-spin"></i><p>Analyzing...</p></div>`;
    analyzeBtn.disabled = true;

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    try {
        const response = await fetch(`${API_URL}/analyze-kolam`, {
            method: 'POST',
            body: formData
        });
        if (!response.ok) throw new Error('Network response was not ok.');

        const data = await response.json();
        if (data.error) throw new Error(data.error);

        displayAnalysisResults(data);

    } catch (error) {
        console.error('Analysis Error:', error);
        resultsContent.innerHTML = `<div class="no-results"><i class="fas fa-exclamation-triangle"></i><p>Analysis failed: ${error.message}. Ensure the Python server is running.</p></div>`;
    } finally {
        analyzeBtn.disabled = false;
    }
}

function displayAnalysisResults(data) {
    const resultsContent = document.getElementById('resultsContent');
    const colorsHtml = data.dominant_colors.map(color => `
        <div class="color-item">
            <div class="color-swatch" style="background-color: ${color};"></div>
            <span>${color}</span>
        </div>`).join('');
    resultsContent.innerHTML = `
        <ul class="analysis-list">
            <li><i class="fas fa-circle"></i><strong>Grid Size:</strong><span>${data.grid_size || 'N/A'}</span></li>
            <li><i class="fas fa-sync-alt"></i><strong>Symmetry:</strong><span>${data.symmetry || 'N/A'}</span></li>
            <li><i class="fas fa-palette"></i><strong>Dominant Colors:</strong><div class="colors-container">${colorsHtml}</div></li>
        </ul>`;
}

// =================================================================
// SECTION 3: NEW DRAWING CANVAS LOGIC
// =================================================================
// FIXED: The drawing logic is now corrected and more efficient.

function initializeDrawingCanvas() {
    const canvas = document.getElementById('drawingCanvas');
    if (!canvas) return; // Exit if canvas not found
    const ctx = canvas.getContext('2d');

    const outputCanvas = document.getElementById('outputCanvas');
    const outCtx = outputCanvas.getContext('2d');
    
    const generateButton = document.getElementById('drawGenerateButton');
    const clearButton = document.getElementById('clearDrawingButton');
    const colorPicker = document.getElementById('colorPicker');

    let isDrawing = false;
    let userStrokes = [];
    let currentStroke = [];
    
    // Set initial drawing styles
    ctx.strokeStyle = '#000'; // User always draws in black
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    function getMousePos(canvasEl, evt) {
        const rect = canvasEl.getBoundingClientRect();
        return {
            x: evt.clientX - rect.left,
            y: evt.clientY - rect.top
        };
    }

    // --- NEW, CORRECTED DRAWING EVENT LISTENERS ---

    canvas.addEventListener('mousedown', (e) => {
        isDrawing = true;
        const pos = getMousePos(canvas, e);
        
        currentStroke = [pos]; // Start a new stroke
        
        ctx.beginPath(); // Start a new path on the canvas
        ctx.moveTo(pos.x, pos.y); // Move the "pen" to the starting point
    });

    canvas.addEventListener('mousemove', (e) => {
        if (!isDrawing) return;
        const pos = getMousePos(canvas, e);
        
        currentStroke.push(pos); // Record the point
        
        ctx.lineTo(pos.x, pos.y); // Draw a line to the new point
        ctx.stroke(); // Render the line
    });

    canvas.addEventListener('mouseup', () => {
        if (!isDrawing) return;
        isDrawing = false;
        if (currentStroke.length > 1) { // Only save meaningful strokes
           userStrokes.push(currentStroke);
        }
    });
    
    canvas.addEventListener('mouseleave', () => { // Stop drawing if mouse leaves canvas
        if(isDrawing) {
            isDrawing = false;
            if (currentStroke.length > 1) {
                userStrokes.push(currentStroke);
            }
        }
    });

    // --- BUTTON AND GENERATION LOGIC (Largely unchanged, but now works) ---
    
    generateButton.addEventListener('click', generateKolamFromDrawing);

    clearButton.addEventListener('click', () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        outCtx.clearRect(0, 0, outputCanvas.width, outputCanvas.height);
        drawGuides(ctx, canvas.width, canvas.height); // Redraw guides
        userStrokes = [];
        currentStroke = [];
    });

    function generateKolamFromDrawing() {
        outCtx.clearRect(0, 0, outputCanvas.width, outputCanvas.height);
        outCtx.lineWidth = 3;
        outCtx.strokeStyle = colorPicker.value; // Use the selected color
        outCtx.lineCap = 'round';
        outCtx.lineJoin = 'round';

        const centerX = outputCanvas.width / 2;
        const centerY = outputCanvas.height / 2;

        userStrokes.forEach(stroke => {
            // Replicate each segment of the stroke symmetrically
            for (let i = 1; i < stroke.length; i++) {
                const p1 = stroke[i - 1];
                const p2 = stroke[i];
                // Convert to vectors from center
                const v1 = { x: p1.x - centerX, y: p1.y - centerY };
                const v2 = { x: p2.x - centerX, y: p2.y - centerY };
                drawSymmetricSegment(v1, v2, centerX, centerY);
            }
        });
    }

    function drawSymmetricSegment(v1, v2, cx, cy) {
        // Top-Left (Original)
        drawFinalLine({ x: cx + v1.x, y: cy + v1.y }, { x: cx + v2.x, y: cy + v2.y });
        // Top-Right (Reflect across Y-axis)
        drawFinalLine({ x: cx - v1.x, y: cy + v1.y }, { x: cx - v2.x, y: cy + v2.y });
        // Bottom-Left (Reflect across X-axis)
        drawFinalLine({ x: cx + v1.x, y: cy - v1.y }, { x: cx + v2.x, y: cy - v2.y });
        // Bottom-Right (Reflect across both axes)
        drawFinalLine({ x: cx - v1.x, y: cy - v1.y }, { x: cx - v2.x, y: cy - v2.y });
    }

    function drawFinalLine(start, end) {
        outCtx.beginPath();
        outCtx.moveTo(start.x, start.y);
        outCtx.lineTo(end.x, end.y);
        outCtx.stroke();
    }
    
    function drawGuides(context, width, height) {
        context.strokeStyle = '#e0e0e0';
        context.lineWidth = 1;
        
        // Vertical guide
        context.beginPath();
        context.moveTo(width / 2, 0);
        context.lineTo(width / 2, height);
        context.stroke();
        
        // Horizontal guide
        context.beginPath();
        context.moveTo(0, height / 2);
        context.lineTo(width, height / 2);
        context.stroke();
    }
    
    // Initial setup
    drawGuides(ctx, canvas.width, canvas.height);
}


// =================================================================
// SECTION 4: UTILITY FUNCTIONS
// =================================================================
function showToast(message, type = 'info') {
    // This is a placeholder for a real toast notification library.
    // For now, it just logs to the console.
    console.log(`[${type.toUpperCase()}] ${message}`);
    // You could replace this with a more visual toast notification.
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => document.body.removeChild(toast), 500);
        }, 3000);
    }, 100);
}

function logout() {
    showToast('User logged out.', 'info');
    // In a real app, you would add logic to clear session/token here.
}




document.addEventListener('DOMContentLoaded', function() {
    
    // This is the entire guided canvas logic.
    function initializeGuidedKolamCanvas() {
        const canvas = document.getElementById('guidedCanvas');
        if (!canvas) {
            console.error("Could not find the canvas element!");
            return;
        }
        const ctx = canvas.getContext('2d');

        const dotCountSlider = document.getElementById('dotCount');
        const colorPicker = document.getElementById('lineColor');
        const clearButton = document.getElementById('clearGuidedBtn');
        const undoButton = document.getElementById('undoGuidedBtn');

        // --- State Variables ---
        let dots = [];
        let path = []; 
        let dotCount = parseInt(dotCountSlider.value, 10);
        const padding = 40;

        function getMousePos(evt) {
            const rect = canvas.getBoundingClientRect();
            return {
                x: evt.clientX - rect.left,
                y: evt.clientY - rect.top
            };
        }

        function redrawAll(liveMousePos = null) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            drawDots();
            drawCommittedPath();
            
            if (path.length > 0 && liveMousePos) {
                drawPreviewLine(liveMousePos);
            }
        }

        function drawDots() {
            ctx.fillStyle = '#ccc';
            dots.forEach(dot => {
                ctx.beginPath();
                ctx.arc(dot.x, dot.y, 4, 0, Math.PI * 2);
                ctx.fill();
            });
        }

        function drawCommittedPath() {
            if (path.length < 2) return;

            ctx.strokeStyle = colorPicker.value;
            ctx.lineWidth = 3;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';

            ctx.beginPath();
            ctx.moveTo(dots[path[0]].x, dots[path[0]].y);
            for (let i = 1; i < path.length; i++) {
                ctx.lineTo(dots[path[i]].x, dots[path[i]].y);
            }
            ctx.stroke();
        }

        function drawPreviewLine(mousePos) {
            const lastDot = dots[path[path.length - 1]];
            ctx.beginPath();
            ctx.moveTo(lastDot.x, lastDot.y);
            ctx.lineTo(mousePos.x, mousePos.y);
            
            ctx.strokeStyle = '#a0a0a0';
            ctx.setLineDash([4, 4]);
            ctx.stroke();
            ctx.setLineDash([]);
        }

        function setupGrid() {
            dots = [];
            path = [];
            dotCount = parseInt(dotCountSlider.value, 10);
            const spacing = (canvas.width - 2 * padding) / (dotCount - 1);
            
            for (let y = 0; y < dotCount; y++) {
                for (let x = 0; x < dotCount; x++) {
                    dots.push({
                        x: padding + x * spacing,
                        y: padding + y * spacing
                    });
                }
            }
            redrawAll();
        }

        // --- Event Listeners ---
        canvas.addEventListener('mousemove', (e) => redrawAll(getMousePos(e)));
        canvas.addEventListener('mouseleave', () => redrawAll(null));

        canvas.addEventListener('click', (e) => {
            const mousePos = getMousePos(e);
            let closestDotIndex = -1;
            let minDistance = 20;

            dots.forEach((dot, index) => {
                const distance = Math.sqrt((dot.x - mousePos.x)**2 + (dot.y - mousePos.y)**2);
                if (distance < minDistance) {
                    minDistance = distance;
                    closestDotIndex = index;
                }
            });

            if (closestDotIndex !== -1 && path[path.length - 1] !== closestDotIndex) {
                path.push(closestDotIndex);
                redrawAll(mousePos);
            }
        });

        undoButton.addEventListener('click', () => {
            if (path.length > 0) {
                path.pop();
                redrawAll();
            }
        });

        clearButton.addEventListener('click', setupGrid);
        dotCountSlider.addEventListener('input', setupGrid);
        colorPicker.addEventListener('input', () => redrawAll());

        // --- Initial Setup ---
        setupGrid();
    }

    // Run the function to activate the canvas
    initializeGuidedKolamCanvas();
});